
%% This file call optimizer and returns the value of parameters to minimize RMSE
clear 
clc
close all
k0 =[7.5701    0.2248    8.5628   10.5515    7.2273    1.2980   18.5489   14.5888];  %%Initial guess from global optimizer
nvars_1 = 8;
lb = 10^-4 + zeros(1,nvars_1);
[k,fval] = ga(@CS_1_ode,nvars_1,[],[],[],[],lb,[]);    %%Global Optimizer
 options = optimset('algorithm','sqp','MaxFunEvals',100000,'MaxIter',100000,'TolFun',1.0000e-10,'TolX',1.0000e-20);  %%SQP algorithm used in fmincon
[k_Optm,fval2] = fmincon(@CS_1_ode,k,[],[],[],[],lb,[],[],options);     %%Local Optimizer
disp(k)
disp(k_Optm)