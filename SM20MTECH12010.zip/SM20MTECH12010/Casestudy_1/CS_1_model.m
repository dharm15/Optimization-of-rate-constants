%%ODE model for case study-1

function f = CS_1_model(t,C,k)
f= zeros(3,1);    %% (3*1) column vector 
u = k(8)*C(1)/(k(1)+C(1));

f(1) = -k(4)*u*C(2);
f(2) = u*C(2)-(k(2)*C(2)/ exp(10*C(1)))-(k(3)*C(2)/ exp(10*C(2)));
f(3) = k(5)*u*C(2)-(k(6)*C(1)/ exp(C(3)))-(k(7)*C(3)/ exp(10*C(1)));

f=[f(1);f(2);f(3)];

end
