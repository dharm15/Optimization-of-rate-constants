%% This function call ODe solver and retuns concentration of different components at different time steps

function [f,t,C] = CS_1_ode(k)
ic = [15,0.5289,0];    %% Initial value of the components
tspan = [0 4 8 12 16 20 24 28 32];

[t,C_fit]=ode45(@(t,C)CS_1_model(t,C,k),tspan,ic);  %% ODE solver 

%% Input Experimental data available
C = [15,0.5289,0;14.32,0.8411,0;11.45,2.68,0.8567;9.21,3.72,1.879;6.432,4.96,2.567;4.567,5.86,2.876;2.734,6.55,2.46;0.643,6.48,1.576;0,6.11,0.645];
plot(t,C,'ro',t,C_fit,'g--')
xlabel('Time(t)');
ylabel('Concentration(C)');
title('Chemical reaction');

%%calculate error between experimental data and simulated data 
my_error = zeros(size(t));

for i = 1:size(C_fit,1)
    for j= i:3
        my_error(i) = my_error(i)+(C(i,j)-C_fit(i,j))^2;
    end
end

f = sqrt(mean(my_error));   %% Returns root mean squar error
end 

        