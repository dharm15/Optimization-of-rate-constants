%%This file calls ODE solver ode45 and returns different values of
%%concentration at different time steps and finally calculate root mean
%%square error between experimental and simulated data 

function [f,t,C] = CS_2_ode(k)
ic = [4.9865,0.6213,0.0,0.0];  %%Initial values of concentration of the components

tspan = [0,3,4,6,8,9,12,15,16,18,20,21,24,27,28,30,32,33];

[t,C_fit]=ode45(@(t,C)CS_2_model(t,C,k),tspan,ic);   %% ODE solver 

%% Input experimental data
C = [4.9865,0.6213,0.0,0.0;4.7459,NaN ,0.0,0.0;NaN ,0.6213,0.0,0.0;4.6023,NaN  ,0.0,0.0;NaN  ,0.6213,NaN  ,0.0;4.5132,NaN  ,0.325,NaN  ;4.107,0.9847,0.453,0.05;3.684,NaN ,0.5372,NaN ;
    NaN ,1.43,NaN ,0.35;3.432,NaN ,0.6921,NaN ;NaN ,1.56,NaN ,0.66;3.16,NaN ,0.684,NaN ;2.659,1.529,0.539,0.85;2.487,NaN ,0.321,NaN ;NaN ,1.4,NaN ,0.93;2.3048,NaN ,0,0.88;NaN ,1.36,0,NaN ;2.12,NaN ,0,NaN];
plot(t,C,'ro',t,C_fit,'g--')
xlabel('Time(t)');
ylabel('Concentration(C)');
title('Chemical reaction');

%% Calculating error between experimental and simulated data 
my_error = zeros(size(t));

for i = 1:size(C_fit,1)
    for j= i:4
        my_error(i) = my_error(i)+(C(i,j)-C_fit(i,j))^2;
    end
end

f = sqrt(mean(my_error));   %% Calculate root mean square error
end 

        