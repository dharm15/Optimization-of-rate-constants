
%% This file calls optimizer and returns optimum value of parameter to minimize RMSE
clear 
clc
close all

k0 = [1.8372    0.0000    0.0000    1.5814    0.0000    0.4228    0.4670    0.0000    0.0000    0.0000    0.6666];  %%Initial guess from global optimizer

nvars_2 = 11;
lb = 10^-4 + zeros(1,nvars_2);
[k,fval] = ga(@CS_2_ode,nvars_2,[] ,[] ,[] ,[] ,lb,[] );    %% Global optimizer
 options = optimset('algorithm','sqp','MaxFunEvals',100000,'MaxIter',100000,'TolFun',1.0000e-10,'TolX',1.0000e-20);    %%SQP algorithm used in fmincon
[k2_Optm,fval2] = fmincon(@CS_2_ode,k,[],[],[],[],lb,[],[],options);   %%Local optimizer
disp(k)
disp(k2_Optm)