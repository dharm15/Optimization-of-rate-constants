%% The ODE Model for casestudy-2

function f = CS_2_model(t,C,k)

f= zeros(4,1);  %%(4*1) column vector
u = k(11)*C(1)/(k(1)+C(1));

f(1) = -k(4)*u*C(2);
f(2) = u*C(2)-(k(3)*C(2)-(k(2)*C(2)/exp(10*C(2))));
f(3) = k(5)*u*C(2)-(k(6)*C(2)*(exp(10*C(1))))-(k(7)*C(3)*(exp(10*C(4))));
f(4) = k(8)*u*C(2)-(k(9)*C(1)/exp(10*C(2)))-(k(10)*C(1)*(exp(10*C(4))));

f = [f(1);f(2);f(3);f(4)];
end
